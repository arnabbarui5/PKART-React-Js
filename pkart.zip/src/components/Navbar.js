import React, { Component } from 'react'
import {Link} from "react-router-dom";
import logo from "../logo.svg";
import { faShoppingCart } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import styled from "styled-components";

export default class Navbar extends Component {
    render() {
        return (
            <NavWrapper className="navbar navbar-expand-sm bg-dark navbar-dark px-sm-5">
                <Link to="/" className="icon-Link">
                        <img src={logo} alt="store" className="navbar-brand"/>
                </Link>
                <ul className="navbar-nav align-items-center">
                    <li className="nav-item ml-5">
                        <Link to="/" className="nav-link">
                            PKART
                        </Link>
                    </li>
                </ul>
                <Link to="/cart" className="ml-auto">
                    <ButtonContainer>
                        <span className="mr-1"><FontAwesomeIcon icon={faShoppingCart} /> </span>My Cart
                </ButtonContainer>
                </Link>
            </NavWrapper>
        );
    }
}

const ButtonContainer = styled.button `

text-transform: capitalize;
font-size: 1.2rem;
background: transparent;
color: var(--mainWhite);
border: 0.05rem solid var(--mainWhite);
border-radius: 0.5rem;
padding: 0.5rem;
cursor: pointer;
margin: 0.1rem 0.05rem 0.1rem 0;
transition: all 0.05s ease-in-out;
&:hover {
    background: var(--mainWhite);
    color: var(--mainDark);
}
&:focus {
    outline: none;
}
`


const NavWrapper = styled.nav`
.nav-link{
    color:var(--mainWhite)!important;
    font-size:1.3rem;
}
}
`;





